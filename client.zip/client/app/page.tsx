import Image from "next/image";
import HomePage from "./(main)/Home/page";

export default function Home() {
  return (
    <div className="flex flex-col flex-1 items-center justify-center">
            <HomePage />
    </div>
  );
}
